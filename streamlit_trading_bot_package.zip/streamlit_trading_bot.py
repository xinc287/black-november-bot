"""
Streamlit Trading Bot - Çok katmanlı analiz (skeleton)
Dosya: streamlit_trading_bot.py
Kullanım:
    pip install -r requirements.txt
    streamlit run streamlit_trading_bot.py
Bu paket bir iskelet sunar. Geliştirme ve ML / On-chain entegrasyonları için
placeholder'lar eklenmiştir.
"""

import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
import matplotlib.pyplot as plt

st.set_page_config(layout="wide", page_title="Trading Bot - Streamlit Skeleton")

# ------------------------- Utility Functions -------------------------

def download_data(ticker: str, period: str = "6mo", interval: str = "1h") -> pd.DataFrame:
    df = yf.download(ticker, period=period, interval=interval, progress=False)
    if df.empty:
        raise ValueError("Veri indirilemedi. Ticker veya interval kontrol edin.")
    df.dropna(inplace=True)
    return df

def sma(series: pd.Series, length: int) -> pd.Series:
    return series.rolling(length).mean()

def ema(series: pd.Series, length: int) -> pd.Series:
    return series.ewm(span=length, adjust=False).mean()

def rsi(series: pd.Series, length: int = 14) -> pd.Series:
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = up.rolling(length).mean()
    ma_down = down.rolling(length).mean()
    rs = ma_up / (ma_down + 1e-9)
    return 100 - (100 / (1 + rs))

def macd(series: pd.Series, fast=12, slow=26, signal=9):
    fast_ema = ema(series, fast)
    slow_ema = ema(series, slow)
    macd_line = fast_ema - slow_ema
    signal_line = ema(macd_line, signal)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram

def bollinger_bands(series: pd.Series, length=20, dev=2):
    ma = series.rolling(length).mean()
    std = series.rolling(length).std()
    upper = ma + dev * std
    lower = ma - dev * std
    bandwidth = (upper - lower) / ma
    percent_b = (series - lower) / (upper - lower + 1e-9)
    return upper, lower, ma, percent_b, bandwidth

def stochastic_oscillator(df: pd.DataFrame, k_period=14, d_period=3):
    low_min = df['Low'].rolling(k_period).min()
    high_max = df['High'].rolling(k_period).max()
    k = 100 * (df['Close'] - low_min) / (high_max - low_min + 1e-9)
    d = k.rolling(d_period).mean()
    return k, d

def atr(df: pd.DataFrame, length=14):
    high_low = df['High'] - df['Low']
    high_close = (df['High'] - df['Close'].shift()).abs()
    low_close = (df['Low'] - df['Close'].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return tr.rolling(length).mean()

# ------------------------- Simple Backtester -------------------------

def simple_signal_generator(df: pd.DataFrame) -> pd.Series:
    ema20 = ema(df['Close'], 20)
    _, _, hist = macd(df['Close'])
    signal = pd.Series(0, index=df.index)
    signal[(df['Close'] > ema20) & (hist > 0)] = 1
    signal[(df['Close'] < ema20) & (hist < 0)] = -1
    return signal

def backtest(df: pd.DataFrame, signal: pd.Series, fee=0.0005):
    positions = signal.replace({-1: -1, 0: 0, 1: 1}).shift().fillna(0)
    returns = df['Close'].pct_change().fillna(0)
    strat_returns = positions * returns
    strat_returns -= fee * positions.diff().abs().fillna(0)
    cum_returns = (1 + strat_returns).cumprod()
    return strat_returns, cum_returns

# ------------------------- Streamlit UI -------------------------

st.title("Trading Bot - Streamlit (Skeleton)")

with st.sidebar:
    st.header("Veri ve Zamanlama")
    ticker = st.text_input("Ticker (yfinance) örn: BTC-USD, EURUSD=X, AAPL", value="BTC-USD")
    period = st.selectbox("Periyot (yfinance)", options=["1mo","3mo","6mo","1y","2y"], index=2)
    interval = st.selectbox("Interval", options=["1m","5m","15m","1h","4h","1d"], index=3)

    st.header("Göstergeler - Tier 1")
    use_sma = st.checkbox("SMA/EMA (9,20,50,100,200)", value=True)
    use_rsi = st.checkbox("RSI (14,21)", value=True)
    use_macd = st.checkbox("MACD (12,26,9)", value=True)
    use_bb = st.checkbox("Bollinger Bands (20,2)", value=True)
    use_stoch = st.checkbox("Stochastic Oscillator", value=False)
    use_atr = st.checkbox("ATR (14)", value=False)
    use_volume = st.checkbox("Volume & Volume MA", value=True)

    if st.button("Veri indir / Yenile"):
        try:
            st.session_state['df'] = download_data(ticker, period=period, interval=interval)
            st.success("Veri indirildi.")
        except Exception as e:
            st.error(f"Veri indirilemedi: {e}")

if 'df' not in st.session_state:
    try:
        st.session_state['df'] = download_data(ticker, period=period, interval=interval)
    except Exception as e:
        st.error(f"Başlangıç veri indirme hatası: {e}")
        st.stop()

df = st.session_state['df'].copy()

if use_sma:
    df['SMA9'] = sma(df['Close'], 9)
    df['SMA20'] = sma(df['Close'], 20)
    df['SMA50'] = sma(df['Close'], 50)
    df['SMA100'] = sma(df['Close'], 100)
    df['SMA200'] = sma(df['Close'], 200)
    df['EMA9'] = ema(df['Close'], 9)
    df['EMA20'] = ema(df['Close'], 20)

if use_rsi:
    df['RSI14'] = rsi(df['Close'], 14)
    df['RSI21'] = rsi(df['Close'], 21)

if use_macd:
    df['MACD'], df['MACD_SIGNAL'], df['MACD_HIST'] = macd(df['Close'])

if use_bb:
    df['BB_UP'], df['BB_LOW'], df['BB_MID'], df['BB_%B'], df['BB_BW'] = bollinger_bands(df['Close'])

if use_stoch:
    df['STOCH_K'], df['STOCH_D'] = stochastic_oscillator(df)

if use_atr:
    df['ATR14'] = atr(df)

st.subheader(f\"Veri: {ticker} - {len(df)} satır\")

# Basit grafik
fig, ax = plt.subplots(figsize=(12,4))
ax.plot(df['Close'], label='Close')
if use_sma:
    ax.plot(df['EMA20'], label='EMA20')
ax.legend()
st.pyplot(fig)

# Sinyal ve backtest
signal = simple_signal_generator(df)
strat_returns, cum_returns = backtest(df, signal)
st.subheader('Basit Backtest - Kümülatif Getiri')
fig2, ax2 = plt.subplots(figsize=(12,4))
ax2.plot(cum_returns, label='Strategy')
ax2.plot((1 + df['Close'].pct_change().fillna(0)).cumprod(), label='Buy & Hold')
ax2.legend()
st.pyplot(fig2)

st.write('Proje dosyaları hazır. Geliştirme için GitHub\'a yükleyin ve ilerleyin.')